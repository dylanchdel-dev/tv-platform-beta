import {Suspense} from 'react';
import {ChannelClient} from '@/components/public/ChannelClient';
export default function Channel(){return <Suspense fallback={<section className="tv-empty">Cargando señal…</section>}><ChannelClient/></Suspense>;}
