import {Suspense} from 'react';
import {HomeClient} from '@/components/public/HomeClient';
export default function Home(){return <Suspense fallback={<section className="tv-empty">Cargando canales…</section>}><HomeClient/></Suspense>;}
