import type { Metadata } from 'next';
import './globals.css';
import './public.css';
import {PublicShell} from '@/components/public/PublicShell';
export const metadata: Metadata = { title: 'SeñalSur — Televisión en directo', robots: { index: false, follow: false } };
export default function Layout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body><main><PublicShell>{children}</PublicShell></main></body></html>;
}
