'use client';
/* eslint-disable @next/next/no-img-element -- Logos remain external, without a server image proxy. */
import {useRef,useState} from 'react';
export function Logo({url,alt='',className='channel-logo'}:{url:string;alt?:string;className?:string}){
 const[failed,setFailed]=useState<string|null>(null);const image=useRef<HTMLImageElement|null>(null);
 return failed===url?<span className="logo-fallback" title="El logo externo no está disponible" aria-label={alt||'Logo no disponible'}>TV</span>:<img ref={node=>{image.current=node;if(node?.complete&&!node.naturalWidth)setFailed(url);}} src={url} alt={alt} className={className} loading="lazy" referrerPolicy="no-referrer" onError={()=>setFailed(url)}/>;
}
