'use client';
import {useEffect,useRef,useState} from 'react';
import Hls from 'hls.js';
import {eligibility,failureMessage,type Candidate,type Failure} from '@/modules/playback/policy';
export function HlsPlayer({candidates,name}:{candidates:Candidate[];name:string}){
 const video=useRef<HTMLVideoElement>(null);const[attempt,setAttempt]=useState(0);const[started,setStarted]=useState(false);const[phase,setPhase]=useState('idle');const[reason,setReason]=useState<Failure|null>(null);const[index,setIndex]=useState(-1);
 useEffect(()=>{
  const current=video.current;if(!current||!started)return;
  const element:HTMLVideoElement=current;
  let cancelled=false;let hls:Hls|null=null;let timer:ReturnType<typeof setTimeout>|undefined;let position=-1;let remove=()=>{};
  const clear=()=>{if(timer)clearTimeout(timer);};
  const release=()=>{clear();remove();hls?.destroy();hls=null;element.pause();element.removeAttribute('src');element.load();};
  function fail(cause:Failure){if(cancelled)return;setReason(cause);tryNext();}
  function watchdog(){clear();timer=setTimeout(()=>fail('TIMEOUT'),15000);}
  function play(){const ticket=position;element.play().catch(error=>{if(cancelled||ticket!==position)return;if(error?.name==='NotAllowedError'){clear();setPhase('ready');}else if(error?.name!=='AbortError')fail('NETWORK');});}
  function tryNext(){
   release();if(cancelled)return;position++;while(position<candidates.length){const blocked=eligibility(candidates[position],window.location.protocol==='https:');if(!blocked)break;setReason(blocked);position++;}
   setIndex(position);if(position>=candidates.length){setPhase('failed');return;}
   setPhase('loading');const chosen=candidates[position];const ticket=position;let failed=false;const onceFail=(cause:Failure)=>{if(!cancelled&&!failed&&ticket===position){failed=true;fail(cause);}};
   const playing=()=>{clear();setPhase('playing');setReason(null);};const waiting=()=>{setPhase('loading');watchdog();};const ready=()=>{clear();setPhase(element.paused?'ready':'playing');};const onError=()=>onceFail(element.error?.code===3?'CODEC':'NETWORK');
   element.addEventListener('playing',playing);element.addEventListener('waiting',waiting);element.addEventListener('canplay',ready);element.addEventListener('error',onError);
   remove=()=>{element.removeEventListener('playing',playing);element.removeEventListener('waiting',waiting);element.removeEventListener('canplay',ready);element.removeEventListener('error',onError);};watchdog();
   if(element.canPlayType('application/vnd.apple.mpegurl')){element.src=chosen.url;play();}
   else if(Hls.isSupported()){
    hls=new Hls({maxBufferLength:20,maxMaxBufferLength:30,manifestLoadingTimeOut:10000,manifestLoadingMaxRetry:1,levelLoadingMaxRetry:1,fragLoadingMaxRetry:1});
    hls.on(Hls.Events.MANIFEST_PARSED,()=>{if(!cancelled&&!failed&&ticket===position)play();});
    hls.on(Hls.Events.ERROR,(_event,data)=>{if(!data.fatal||failed||cancelled)return;const code=data.response?.code;onceFail(code===401?'AUTH':code===451?'GEO':data.type===Hls.ErrorTypes.MEDIA_ERROR?'CODEC':'NETWORK');});
    hls.loadSource(chosen.url);hls.attachMedia(element);
   }else onceFail('UNSUPPORTED');
  }
  tryNext();return()=>{cancelled=true;release();};
 },[candidates,started,attempt]);
 return <section className="tv-player" aria-label={`Reproductor de ${name}`} data-phase={phase} data-attempt={index} data-reason={reason||''}>
  <video ref={video} controls playsInline preload="none" aria-label={name}/>
  {!started&&<div className="player-cover"><span className="play-symbol" aria-hidden="true">▶</span><h2>{name}</h2><p>Elige reproducir para conectar con la señal.</p><button onClick={()=>setStarted(true)}>Reproducir señal</button></div>}
  <div className="player-status" role="status" aria-live="polite">{phase==='loading'&&<><span className="loading-dot"/> Conectando con la señal…</>}{phase==='playing'&&<><span className="live-dot"/> Reproduciendo</>}{phase==='ready'&&<button onClick={()=>void video.current?.play().catch(()=>{})}>Reproducir</button>}{phase==='failed'&&<><strong>Señal temporalmente no disponible</strong><p>{reason?failureMessage(reason):'No hay alternativas disponibles para esta señal.'}</p><button onClick={()=>{setReason(null);setAttempt(a=>a+1);}}>Reintentar</button></>}</div>
 </section>;
}
