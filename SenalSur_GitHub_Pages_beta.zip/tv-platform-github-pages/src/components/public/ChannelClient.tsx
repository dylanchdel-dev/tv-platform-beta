'use client';
import Link from 'next/link';
import {useSearchParams} from 'next/navigation';
import {HlsPlayer} from '@/components/player/HlsPlayer';
import {Logo} from '@/components/admin/Logo';
import {countryNames} from '@/components/public/ChannelCard';
import {CatalogLoading,useCatalog} from '@/lib/public-data';
export function ChannelClient(){
 const query=useSearchParams();const{data}=useCatalog();if(!data)return <CatalogLoading/>;
 const c=data.channels.find(c=>c.id===query.get('id'));const selected=query.get('feed');const feed=c&&(selected?c.feeds.find(f=>f.id===selected):c.feeds[0]);
 if(!c||(selected&&!feed))return <section className="tv-empty"><h1>Canal o señal no disponible</h1><p>Vuelve al catálogo para elegir otra señal.</p><Link href="/">Explorar canales</Link></section>;
 return <article className="tv-channel-page"><Link className="tv-back" href={c.country&&countryNames[c.country]?`/?country=${c.country}`:'/'}>← Explorar canales</Link><header className="tv-channel-heading"><div className="tv-detail-logo">{c.logo?<Logo url={c.logo} alt=""/>:<span>TV</span>}</div><div><p className="tv-eyebrow">{countryNames[c.country||'']||c.country||'Internacional'}</p><h1>{c.name||'Canal sin nombre'}</h1><p>{c.categories.map(id=>data.categories.find(x=>x.id===id)?.name||id).join(' · ')||'Televisión'}</p></div><span className="tv-beta">BETA</span></header>
 {c.feeds.length>1&&<nav className="tv-feeds" aria-label="Elegir señal">{c.feeds.map(f=><Link key={f.id} className={feed?.id===f.id?'selected':''} href={`/channel/?id=${c.id}&feed=${f.id}`}>{f.name}</Link>)}</nav>}
 {feed?.candidates.length?<HlsPlayer key={`${c.id}:${feed.id}`} name={c.name} candidates={feed.candidates}/>:<div className="tv-no-signal"><span aria-hidden="true">◌</span><h2>Sin fuente de reproducción</h2><p>El catálogo no incluye una URL de reproducción para esta señal. Reintentar no puede conectarla sin una fuente.</p><Link href="/">Explorar otros canales</Link></div>}
 <div className="tv-channel-note"><h2>{feed?.name||'Acerca de esta señal'}</h2><p>La disponibilidad depende de la fuente y de tu ubicación. Si una alternativa falla, intentamos la siguiente de esta misma señal. Puedes elegir otra señal manualmente.</p>{feed?.candidates.some(s=>s.geoblocked)&&<p>La fuente informa posibles restricciones geográficas.</p>}</div></article>;
}
