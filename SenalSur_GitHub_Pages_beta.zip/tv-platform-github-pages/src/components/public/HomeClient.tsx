'use client';
import Link from 'next/link';
import {useRouter,useSearchParams} from 'next/navigation';
import {ChannelCard,countryNames} from '@/components/public/ChannelCard';
import {CatalogLoading,useCatalog} from '@/lib/public-data';
export function HomeClient(){
 const router=useRouter();const raw=useSearchParams();const{data}=useCatalog();
 if(!data)return <CatalogLoading/>;
 const q=(raw.get('q')||'').slice(0,200),country=raw.get('country')||'',category=raw.get('category')||'';
 const query=q.toLocaleLowerCase('es');
 const filtered=data.channels.filter(c=>(!query||[c.name,c.originalName,c.externalId,...c.alternativeNames].some(name=>name?.toLocaleLowerCase('es').includes(query)))&&(!country||(country==='OTHER'?!['AR','CL','PE','PY'].includes(c.country||''):c.country===country))&&(!category||c.categories.includes(category)));
 const total=filtered.length,pages=Math.max(1,Math.ceil(total/25)),requested=Number(raw.get('page')||1),page=Math.min(pages,Math.max(1,Number.isFinite(requested)?Math.floor(requested):1));const rows=filtered.slice((page-1)*25,page*25);
 const link=(p:number)=>'/?'+new URLSearchParams({q,country,category,page:String(p)});const categoryName=(id:string)=>data.categories.find(c=>c.id===id)?.name;
 return <><section className="tv-hero"><div><p className="tv-eyebrow"><span className="live-dot"/> TU REGIÓN, EN PANTALLA</p><h1>Tu próxima señal.<br/><span>Más cerca.</span></h1><p>Explora televisión de Argentina, Chile, Perú y Paraguay.<br className="desktop-only"/> Elige un canal y encuentra tu señal.</p></div><div className="tv-hero-art" aria-hidden="true"><div className="tv-orbit orbit-one"/><div className="tv-orbit orbit-two"/><div className="tv-orbit orbit-three"/><span className="tv-hero-screen">▶</span><span className="signal-tag">AR · CL · PE · PY</span></div></section>
 <section className="tv-catalog" aria-labelledby="catalog-heading"><div className="tv-country-tabs"><Link className={!country?'selected':''} href="/">Todos</Link>{Object.entries(countryNames).map(([code,name])=><Link className={country===code?'selected':''} key={code} href={`/?country=${code}`}>{name}</Link>)}</div>
 <div className="tv-catalog-heading"><div><p className="tv-eyebrow">EXPLORA A TU RITMO</p><h2 id="catalog-heading">Canales de televisión <span>{total}</span></h2></div><p>Catálogo disponible · {page} / {pages}</p></div>
 <form key={raw.toString()} className="tv-filters" onSubmit={event=>{event.preventDefault();const values=new FormData(event.currentTarget);router.push('/?'+new URLSearchParams({q:String(values.get('q')||''),country:String(values.get('country')||''),category:String(values.get('category')||''),page:'1'}));}}><label className="tv-search">Buscar canal<input name="q" defaultValue={q} placeholder="¿Qué quieres ver?" maxLength={200}/></label><label>País<select name="country" defaultValue={country}><option value="">Todos los países</option>{Object.entries(countryNames).map(([c,n])=><option key={c} value={c}>{n}</option>)}<option value="OTHER">Internacional / otros</option></select></label><label>Categoría<select name="category" defaultValue={category}><option value="">Todas las categorías</option>{data.categories.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label><button>Buscar</button></form>
 <div className="tv-grid">{rows.map(c=><ChannelCard key={c.id} channel={c} category={categoryName(c.categories[0])}/>)}</div>{!rows.length&&<div className="tv-empty"><h2>No encontramos canales</h2><p>Prueba otro nombre o cambia los filtros.</p><Link href="/">Ver todos</Link></div>}
 <nav className="tv-pagination" aria-label="Paginación">{page>1?<Link href={link(page-1)}>← Anterior</Link>:<span/>}<span>Página {page} de {pages} · {total} canales</span>{page<pages?<Link href={link(page+1)}>Siguiente →</Link>:<span/>}</nav></section></>;
}
