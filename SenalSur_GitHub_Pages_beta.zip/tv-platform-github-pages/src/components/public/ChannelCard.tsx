import Link from 'next/link';
import {Logo} from '@/components/admin/Logo';
import {eligibility} from '@/modules/playback/policy';
import type {Channel} from '@/lib/public-data';
export const countryNames:Record<string,string>={AR:'Argentina',CL:'Chile',PE:'Perú',PY:'Paraguay'};
export function ChannelCard({channel,category}:{channel:Pick<Channel,'id'|'name'|'country'|'logo'|'feeds'>;category?:string}){
 const candidates=channel.feeds.flatMap(feed=>feed.candidates);
 const compatible=candidates.some(candidate=>!eligibility(candidate,true));
 const sourceLabel=!candidates.length?'Sin fuente de reproducción':compatible?'Fuente por comprobar':'Fuente no compatible';
 return <Link className="tv-card" href={`/channel/?id=${channel.id}`}><div className="tv-card-art">{channel.logo?<Logo url={channel.logo} alt=""/>:<span className="tv-monogram">{channel.name.slice(0,2).toUpperCase()}</span>}<span className="tv-card-play" aria-hidden="true">▶</span></div><div className="tv-card-copy"><span className="tv-card-country">{countryNames[channel.country||'']||channel.country||'Internacional'} {category&&` · ${category}`}</span><h2>{channel.name||'Canal sin nombre'}</h2><span className="tv-unavailable">{sourceLabel}</span></div></Link>;
}
