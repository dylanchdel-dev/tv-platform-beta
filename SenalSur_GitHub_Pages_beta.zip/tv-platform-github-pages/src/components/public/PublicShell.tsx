'use client';
import Link from 'next/link';
import {CatalogProvider,useCatalog,validationDate} from '@/lib/public-data';
function Footer(){const{data}=useCatalog();return <footer className="tv-footer"><span>SeñalSur · Televisión por Internet{data&&` · Prueba de reproducción: ${validationDate(data.validatedOn)}`}</span><span>Las señales se reproducen directamente desde sus fuentes.</span></footer>;}
export function PublicShell({children}:{children:React.ReactNode}){return <CatalogProvider><div className="tv-public"><header className="tv-header"><Link href="/" className="tv-wordmark"><span className="tv-icon">▶</span> Señal<span className="tv-wordmark-light">Sur</span><small>BETA</small></Link><nav aria-label="Navegación principal"><Link href="/">Explorar canales</Link></nav></header>{children}<Footer/></div></CatalogProvider>;}
