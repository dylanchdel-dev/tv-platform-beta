export type Candidate = {id:string;url:string;requiresHeaders:boolean;geoblocked:boolean};
export type Failure = 'HEADERS'|'HTTPS'|'AUTH'|'GEO'|'CODEC'|'NETWORK'|'TIMEOUT'|'UNSUPPORTED';
export function eligibility(s:Candidate,secure:boolean):Failure|null {
  if(s.requiresHeaders)return 'HEADERS';
  try {const u=new URL(s.url);if(!['http:','https:'].includes(u.protocol)||u.username||u.password)return 'UNSUPPORTED';if(secure&&u.protocol!=='https:')return 'HTTPS';}catch{return 'UNSUPPORTED';}
  return null;
}
export function failureMessage(reason:Failure){return ({HEADERS:'Esta fuente requiere condiciones de acceso que el navegador no puede aplicar.',HTTPS:'Esta fuente no dispone de una conexión segura compatible con esta página.',AUTH:'La fuente requiere autorización.',GEO:'La fuente indica una restricción de acceso por región.',CODEC:'El formato de video no es compatible con este navegador.',NETWORK:'No se pudo conectar con la fuente. Puede deberse a la red, permisos CORS o restricciones regionales.',TIMEOUT:'La fuente no respondió a tiempo.',UNSUPPORTED:'Esta fuente no es compatible con reproducción directa.'})[reason];}
export function nextCandidate(candidates:Candidate[],after:number,secure:boolean){for(let i=after+1;i<candidates.length;i++)if(!eligibility(candidates[i],secure))return i;return -1;}
