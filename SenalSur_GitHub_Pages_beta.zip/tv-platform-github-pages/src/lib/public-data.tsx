'use client';
import {createContext,useContext,useEffect,useState} from 'react';
import type {Candidate} from '@/modules/playback/policy';
export type Feed={id:string;name:string;isMain:boolean;languages:string[];candidates:Candidate[]};
export type Channel={id:string;name:string;originalName:string;externalId:string|null;alternativeNames:string[];country:string|null;categories:string[];logo:string|null;available:boolean;feeds:Feed[]};
export type Catalog={version:1;catalogDate:string;categories:{id:string;name:string}[];channels:Channel[]};
export const basePath=process.env.NEXT_PUBLIC_BASE_PATH||'/tv-platform-beta';
const Context=createContext<{data:Catalog|null;error:boolean}>({data:null,error:false});
export function CatalogProvider({children}:{children:React.ReactNode}){
 const[data,setData]=useState<Catalog|null>(null);const[error,setError]=useState(false);
 useEffect(()=>{const controller=new AbortController();fetch(`${basePath}/catalog.json`,{signal:controller.signal}).then(async response=>{if(!response.ok)throw Error('catalog');const result:Catalog=await response.json();if(result.version!==1||!Array.isArray(result.channels))throw Error('catalog');result.channels.sort((a,b)=>a.name.localeCompare(b.name,'es')||a.id.localeCompare(b.id));setData(result);}).catch(e=>{if(e.name!=='AbortError')setError(true);});return()=>controller.abort();},[]);
 return <Context.Provider value={{data,error}}>{children}</Context.Provider>;
}
export const useCatalog=()=>useContext(Context);
export function CatalogLoading(){const{error}=useCatalog();return <section className="tv-empty" role="status"><h1>{error?'No pudimos cargar los canales':'Cargando canales…'}</h1>{error&&<><p>Vuelve a intentarlo en unos momentos.</p><button onClick={()=>window.location.reload()}>Reintentar</button></>}</section>;}
